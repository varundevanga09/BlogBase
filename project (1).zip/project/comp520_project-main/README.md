# comp520_project
blogging service

## How to start dev env

on this root directory

```
$ docker-compose up
```

and open an web app

http://localhost:8080

and open mysql workbench

- hostname: `127.0.0.1`
- port: `3306`
- username: `root`
- password: `pass`
